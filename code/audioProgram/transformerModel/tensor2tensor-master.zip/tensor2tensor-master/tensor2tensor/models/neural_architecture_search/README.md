This directory contains the configurable model code used in the Evolved
Transformer paper (https://arxiv.org/abs/1901.11117). It can be used to train
models in the search space as was done in the paper.
