# Assessing the Factual Accuracy of Generated Text

This directory will contain the code and scripts to generate data and train
models from the paper *Assessing the Factual Accuracy of Generated Text*.
